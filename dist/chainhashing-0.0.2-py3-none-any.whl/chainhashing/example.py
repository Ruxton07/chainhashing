class Maxim:
    def __init__(self):
        self.name = "Maxim"
    def say_hello(self):
        return f"Hello, my name is {self.name}!"

def test():
    print("Hello, World!")