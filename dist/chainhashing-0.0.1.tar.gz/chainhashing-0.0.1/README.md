An example package/library for python that I made to prepare for deploying my first real package. This package does not actually do anything.
